import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ozel',
  templateUrl: './ozel.component.html',
  styleUrls: ['./ozel.component.css']
})
export class OzelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
