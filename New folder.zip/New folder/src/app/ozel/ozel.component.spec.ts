import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OzelComponent } from './ozel.component';

describe('OzelComponent', () => {
  let component: OzelComponent;
  let fixture: ComponentFixture<OzelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OzelComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OzelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
