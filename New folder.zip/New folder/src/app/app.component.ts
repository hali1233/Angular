import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Ozel';
  data ="Learn Coding With Angular"
  getValue(){
    return "Welcome to CureMd MEAN BootCamp Programe"
  }
  name="Hamza"
  disable=false;
}
